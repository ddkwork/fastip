package main

import (
	"context"
	"encoding/json"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"os"
	"sort"
	"sync"
	"time"
)

type GitHubMeta struct {
	Git []string `json:"git"`
}

type IPResult struct {
	IP         string  `json:"ip"`
	Latency    float64 `json:"latency"`    // 毫秒
	Speed      float64 `json:"speed"`      // KB/s
	PacketLoss float64 `json:"packetLoss"` // 丢包率
	Score      float64 `json:"score"`      // 综合评分
}

const (
	testFileURL   = "https://github.com/favicon.ico" // 测试文件 (4.5KB)
	sampleTimes   = 3                                // 每IP测试次数
	minValidScore = 0.5                              // 最低有效分数
	testFileSize  = 4500                             // 测试文件大小 (bytes)
)

func main() {
	log.Println("Starting GitHub High-Speed IP Finder")

	// 获取GitHub CIDR列表
	cidrs, err := getGitHubCIDRs()
	if err != nil {
		log.Fatalf("Failed to get GitHub CIDRs: %v", err)
	}

	// 处理CIDR范围
	testIPs := parseCIDRs(cidrs)
	log.Printf("Found %d IPs to test", len(testIPs))

	// 并发测试IP性能
	results := testIPsConcurrently(testIPs)

	// 排序并选择最佳IP
	bestIP := selectBestIP(results)

	// 保存结果
	saveResults(bestIP, results)

	log.Printf("Best IP found: %s (Score: %.2f)", bestIP.IP, bestIP.Score)
}

func getGitHubCIDRs() ([]string, error) {
	resp, err := http.Get("https://api.github.com/meta")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var meta GitHubMeta
	if err := json.Unmarshal(body, &meta); err != nil {
		return nil, err
	}

	return meta.Git, nil
}

func parseCIDRs(cidrs []string) []string {
	var ips []string
	for _, cidr := range cidrs {
		ip, _, err := net.ParseCIDR(cidr)
		if err == nil {
			ips = append(ips, ip.String())
		}
	}
	return ips
}

func testIPPerformance(ip string) IPResult {
	result := IPResult{IP: ip}

	// 测试延迟和丢包率
	latencies := make([]float64, 0, sampleTimes)
	successCount := 0

	for i := 0; i < sampleTimes; i++ {
		start := time.Now()
		conn, err := net.DialTimeout("tcp", ip+":443", 2*time.Second)
		if err == nil {
			conn.Close()
			latency := time.Since(start).Seconds() * 1000 // ms
			latencies = append(latencies, latency)
			successCount++
		}
		time.Sleep(300 * time.Millisecond)
	}

	// 计算平均延迟和丢包率
	if successCount > 0 {
		totalLatency := 0.0
		for _, l := range latencies {
			totalLatency += l
		}
		result.Latency = totalLatency / float64(successCount)
	}
	result.PacketLoss = (1 - float64(successCount)/float64(sampleTimes)) * 100

	// 测试下载速度
	if result.PacketLoss < 50 { // 只有丢包率低于50%才测试速度
		speed := testDownloadSpeed(ip)
		if speed > 0 {
			result.Speed = speed
		}
	}

	// 计算综合评分 (速度权重最高)
	result.Score = calculateScore(result)

	return result
}

func testDownloadSpeed(ip string) float64 {
	client := http.Client{
		Transport: &http.Transport{
			DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
				// 强制使用指定IP
				return net.Dial(network, ip+":443")
			},
		},
		Timeout: 5 * time.Second,
	}

	// 多次测量取最优值
	bestSpeed := 0.0

	for i := 0; i < sampleTimes; i++ {
		start := time.Now()
		resp, err := client.Get(testFileURL)
		if err != nil {
			continue
		}

		// 完整下载文件
		_, err = io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
		if err != nil {
			continue
		}

		duration := time.Since(start).Seconds()
		speedKBps := (testFileSize / 1024) / duration

		if speedKBps > bestSpeed {
			bestSpeed = speedKBps
		}

		time.Sleep(500 * time.Millisecond) // 间隔避免请求限制
	}

	return bestSpeed
}

func calculateScore(result IPResult) float64 {
	// 分数计算权重：
	// 下载速度: 60%
	// 延迟: 30%
	// 丢包率: 10%

	speedScore := math.Min(result.Speed/1000, 1.0) // 1000KB/s为满分

	latencyScore := 0.0
	if result.Latency > 0 {
		latencyScore = math.Max(0, 1-(result.Latency/1000)) // 延迟1s为0分
	}

	packetLossScore := 1 - (result.PacketLoss / 100)

	return speedScore*0.6 + latencyScore*0.3 + packetLossScore*0.1
}

func testIPsConcurrently(ips []string) []IPResult {
	var wg sync.WaitGroup
	results := make(chan IPResult, len(ips))
	allResults := make([]IPResult, 0, len(ips))

	for _, ip := range ips {
		wg.Add(1)
		go func(ip string) {
			defer wg.Done()
			result := testIPPerformance(ip)
			if result.Score >= minValidScore {
				results <- result
			}
		}(ip)
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	for result := range results {
		allResults = append(allResults, result)
	}

	return allResults
}

func selectBestIP(results []IPResult) IPResult {
	if len(results) == 0 {
		// 退回默认IP
		return IPResult{
			IP:    "140.82.113.3",
			Speed: 500,
			Score: 0.5,
		}
	}

	// 按分数排序
	sort.Slice(results, func(i, j int) bool {
		return results[i].Score > results[j].Score
	})

	return results[0]
}

func saveResults(bestIP IPResult, allResults []IPResult) {
	// 创建输出目录
	if err := os.MkdirAll("results", 0755); err != nil {
		log.Fatalf("Failed to create results dir: %v", err)
	}

	// 保存最佳IP
	saveIPToFile("results/fastest_ip.txt", bestIP.IP)

	// 保存完整结果报告
	saveJSONReport("results/ip_report.json", allResults, bestIP)
}

func saveIPToFile(filename, ip string) {
	file, err := os.Create(filename)
	if err != nil {
		log.Printf("Failed to create %s: %v", filename, err)
		return
	}
	defer file.Close()

	if _, err := file.WriteString(ip); err != nil {
		log.Printf("Failed to write to %s: %v", filename, err)
	}
}

func saveJSONReport(filename string, results []IPResult, best IPResult) {
	type FullReport struct {
		Timestamp string     `json:"timestamp"`
		TestedIPs int        `json:"tested_ips"`
		BestIP    IPResult   `json:"best_ip"`
		AllIPs    []IPResult `json:"all_ips"`
	}

	report := FullReport{
		Timestamp: time.Now().UTC().Format(time.RFC3339),
		TestedIPs: len(results),
		BestIP:    best,
		AllIPs:    results,
	}

	file, err := os.Create(filename)
	if err != nil {
		log.Printf("Failed to create report: %v", err)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(report); err != nil {
		log.Printf("Failed to encode report: %v", err)
	}
}
